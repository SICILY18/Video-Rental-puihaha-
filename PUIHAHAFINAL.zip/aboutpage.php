<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgba(255, 255, 255, 0.25);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }

        .container {
            background: rgba(255, 255, 255, 0.15); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 900px;
            width: 90%;
            margin: 120px 20px 20px; /* Added top margin to create space from navbar */
            text-align: center;
            backdrop-filter: blur(10px); /* Blur effect for glass effect */
            -webkit-backdrop-filter: blur(10px); /* For Safari */
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .profile-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px 0;
        }

        .profile {
            text-align: center;
            margin: 20px;
        }

        .profile img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ccc;
        }

        .profile h2 {
            font-size: 1.2em;
            margin: 10px 0 5px;
            color: #333;
        }

        .profile p {
            color: #777;
            font-size: 0.9em;
        }

        .social-links a {
            margin: 0 10px;
            color: #555;
            text-decoration: none;
            transition: color 0.3s;
        }

        .social-links a:hover {
            color: #333;
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 50px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }

        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
        }

        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }

        @media screen and (max-width: 1160px) {
            .nav {
                padding: 15px 20px;
            }
            .nav .search-box {
                right: 100px;
            }
        }

        @media screen and (max-width: 950px) {
            .nav {
                padding: 15px 20px;
            }
            .nav .search-box {
                right: 100px;
                max-width: 250px;
            }
        }

        @media screen and (max-width: 768px) {
            .nav {
                padding: 15px 20px;
            }
            .nav .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                height: 100%;
                max-width: 280px;
                width: 100%;
                padding-top: 100px;
                row-gap: 30px;
                flex-direction: column;
                background-color: #11101d;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                transition: all 0.4s ease;
                z-index: 100;
            }
            .nav.openNav .nav-links {
                left: 0;
            }
            .nav .navOpenBtn {
                display: block;
                color: #fff;
                font-size: 20px;
                cursor: pointer;
            }
            .nav .navCloseBtn {
                display: block;
                position: absolute;
                top: 20px;
                right: 20px;
                color: #fff;
                font-size: 20px;
                cursor: pointer;
            }
            .nav .search-box {
                top: calc(100% + 10px);
                max-width: calc(100% - 20px);
                right: 50%;
                transform: translateX(50%);
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
        }
    </style>
</head>

<body>

<nav class="nav">
    <i class="uil uil-bars navOpenBtn"></i>
    <a href="#" class="logo">Puihaha Video Production</a>
    <ul class="nav-links">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
    </ul>
</nav>

<div class="container">
    <h1>About Us</h1>
    <p>
        Welcome to our Video Rental System! We are dedicated to providing the best rental experience for our customers. Our vast collection of movies and TV shows ensures that there is something for everyone.
    </p>

    <h2>Our Mission</h2>
    <p>
        Our mission is to deliver top-quality service and entertainment to our users. We believe in the power of stories and strive to bring you the best titles from around the world.
    </p>
    
    <h2>Our Vision</h2>
    <p>
        To become the leading provider of video rental services, offering a diverse range of movies and TV shows that cater to all tastes and preferences.
    </p>

    <h2>Our History</h2>
    <p>
        Founded in 2024, our company has grown from a small startup to a reputable service provider with a vast collection of entertainment options. Key milestones include expanding our catalog to include over 10,000 titles, achieving a customer satisfaction rating of over 95%, and establishing partnerships with leading studios worldwide.
    </p>

    <h2>Our Values</h2>
    <p>
         Commitment to Quality<br>
         Customer Satisfaction<br>
         Innovation<br>
         Integrity<br>
    </p>
</div>

<div class="container">
    <h2>Meet Our Team</h2>
    <div class="profile-container">
        <div class="profile">
            <img src="https://scontent.fmnl4-1.fna.fbcdn.net/v/t1.15752-9/449057503_442674265225690_6741491277748115651_n.png?_nc_cat=106&ccb=1-7&_nc_sid=9f807c&_nc_ohc=FnBNFh61YO8Q7kNvgHtERIl&_nc_ht=scontent.fmnl4-1.fna&oh=03_Q7cD1QH24y3N6ozaaiS02yDKu7jXrMEjnoQ0Buht8_poVkn55w&oe=66B0F7BE" alt="Member 1">
            <h2>Leo Jelo Abellanida</h2>
            <p>Role: Developer</p>
        </div>
        <div class="profile">
            <img src="https://scontent.xx.fbcdn.net/v/t1.15752-9/448560924_361031700020692_4070205507728754756_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=0024fc&_nc_ohc=aTIoxMrlqzkQ7kNvgFzD6Wn&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QHslI_KkEh4DHOPRSMqjEA3AdPYNkcu-9QCZRcTV8Dnhw&oe=66B0D2EF" alt="Member 2">
            <h2>Stephannie Tullao</h2>
            <p>Role: Developer</p>
        </div>
        <div class="profile">
            <img src="https://scontent.xx.fbcdn.net/v/t1.15752-9/449080808_2007422493010009_751163846060909246_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=0024fc&_nc_ohc=A3B_H_H6xQoQ7kNvgHZF028&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QF3ZK7fGS17JdCMxlBnQrcUlbkxE7K2R7RpKQ7MfoAMlw&oe=66B0E212" alt="Member 3">
            <h2>Faith Jane Cieolo Ajoc</h2>
            <p>Role: Developer</p>
        </div>
        <div class="profile">
            <img src="https://scontent.fmnl4-2.fna.fbcdn.net/v/t1.15752-9/449177557_4073138126246147_5398263014558862717_n.png?_nc_cat=101&ccb=1-7&_nc_sid=9f807c&_nc_ohc=TIBeicaFs_AQ7kNvgF9rSAj&_nc_ht=scontent.fmnl4-2.fna&oh=03_Q7cD1QETxgNlwLdh5oXw_SalhIMlU_-VaI9DOvsF2pDdCkh30Q&oe=66B0D667" alt="Member 4">
            <h2>Rhadler Klein Cedric Umali</h2>
            <p>Role: Developer</p>
        </div>
    </div>
    <h2>Contact Us</h2>
    <p>
        Email: support@videorentalsystem.com<br>
        Phone: (123) 456-7890
    </p>

    <h2>Follow Us</h2>
    <p>
        <a href="https://www.facebook.com">Facebook</a><br>
        <a href="https://www.twitter.com">Twitter</a><br>
        <a href="https://www.instagram.com">Instagram</a>
    </p>
</div>

<div class="wave"></div>
<div class="wave"></div>
<div class="wave"></div>
</body>
</html>