<?php
$host = 'localhost';
$dbname = 'u675966424_rentdb'; // Update database name here
$username = 'u675966424_umali'; // Update username if different
$password = 'Stephganda2003$'; // Update password if set

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: Could not connect. " . $e->getMessage());
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if necessary keys exist in $_POST array
    if (isset($_POST['movie_id'], $_POST['movie_year'], $_POST['genre'], $_POST['image_link'])) {
        $movie_id = $_POST['movie_id'];
        $movie_year = $_POST['movie_year'];
        $genre = $_POST['genre'];
        $image_link = $_POST['image_link'];

        // Insert movie into database
        // Adjusted SQL query in add.php
$sql = "INSERT INTO movies (movie_id, movie_year, genre, image_link) VALUES (:movie_id, :movie_year, :genre, :image_link)";

        $stmt = $pdo->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':movie_id', $movie_id, PDO::PARAM_STR);
        $stmt->bindParam(':movie_year', $movie_year, PDO::PARAM_INT);
        $stmt->bindParam(':genre', $genre, PDO::PARAM_STR);
        $stmt->bindParam(':image_link', $image_link, PDO::PARAM_STR);

        // Execute statement
        try {
            $stmt->execute();

            // Redirect to homepage.php or rent.php with appropriate logic
      header("Location: rent.php?movie_id=" . $movie_id);
exit();

        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }
    } else {
        die("Error: Form fields not properly submitted.");
    }
}
?>
<!-- HTML form to add a movie -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add a Movie</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" href="style.css" />
    <!-- Unicons CSS -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <!-- Additional CSS styles -->
    <style>
        /* Google Fonts - Poppins */
        
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        
        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }
        
        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }
        
        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }
        
        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }
        
        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }
        
        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }
        
        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }
        
        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }
        
        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }
       
        /* Add these styles to adjust the layout and spacing */
        
        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }
        
        .rentcard {
            width: 100%;
            max-width: 500px;
            /* Adjust the maximum width as needed */
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        
        .rentcard:hover {
            transform: translateY(-5px);
        }
        
        .rentcard-content {
            padding: 20px;
        }
        
        .rentcard-content form {
            display: grid;
            gap: 15px;
            /* Adjust the gap between elements */
        }
        
        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
            /* Add margin below each label */
        }
        
        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            /* Add margin at the top of fieldset */
        }
        
        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .rentcard-content button:hover {
            background-color: #0056b3;
        }
        /* Global styles and imports remain the same */
        /* Adjustments for responsiveness */
        
        @media (max-width: 768px) {
            .nav {
                padding: 15px 20px;
                /* Adjust padding for smaller screens */
            }
            .nav .nav-links {
                margin-right: 20px;
                /* Reduce margin for smaller screens */
            }
            .rentcont {
                padding: 10px;
            }
            .rentcard {
                max-width: 100%;
            }
            .rentcard-content form {
                display: flex;
                flex-direction: column;
            }
            .rentcard-content label {
                margin-bottom: 10px;
            }
            .rentcard-content input[type="text"],
            .rentcard-content input[type="number"],
            .rentcard-content input[type="url"],
            .rentcard-content fieldset {
                width: 100%;
                padding: 8px;
                font-size: 0.9rem;
            }
            .rentcard-content button {
                padding: 12px 20px;
            }
        }
    </style>
</head>

<body>
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <li><a href="homepage.php">Home</a></li>
            <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
    
    </nav>
    <!-- end of navbar -->

   <div class="rentcont">
      <h1>Add a Movie Form</h1>
        <div class="rentcard">
            <div class="rentcard-content">
                <form action="add.php" method="POST">
                    <label for="movie-name">Movie Name:</label>
                    <input type="text" id="movie-name" name="movie_id" required>
    
                    <label for="movie-year">Movie Year:</label>
                    <input type="number" id="movie-year" name="movie_year" min="1900" max="2099" required>
    
                    <label for="image-link">Image Link:</label>
                    <input type="url" id="image-link" name="image_link" required>
    
                    <fieldset>
                        <legend>Genre:</legend>
                        <label><input type="radio" name="genre" value="action" required> Action</label>
                        <label><input type="radio" name="genre" value="comedy"> Comedy</label>
                        <label><input type="radio" name="genre" value="drama"> Drama</label>
                        <label><input type="radio" name="genre" value="horror"> Horror</label>
                        <label><input type="radio" name="genre" value="sci-fi"> Sci-Fi</label>
                    </fieldset>
    
                    <button type="submit">Rent Now</button>
                </form>

            </div>
        </div>
    </div>
</body>
</html>