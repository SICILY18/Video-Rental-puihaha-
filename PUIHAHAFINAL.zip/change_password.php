<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }

            25% {
                transform: translateX(-25%);
            }

            50% {
                transform: translateX(-50%);
            }

            75% {
                transform: translateX(-25%);
            }

            100% {
                transform: translateX(1);
            }
        }

        .container {
            max-width: 700px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        button[type="submit"] {
            width: 100%;
        }

        .alert {
            margin-top: 20px;
        }

        .picture-container {
            flex: 1;
            position: relative;
            overflow: hidden;
        }

        .picture-container img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: auto;
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
        }
    </style>
</head>
<body>
<div>
     <div class="wave"></div>
     <div class="wave"></div>
     <div class="wave"></div>
</div>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h2>Change Password</h2>
            <form method="post" action="change_password.php">
                <input type="hidden" name="token" value="<?php echo isset($_GET['token']) ? $_GET['token'] : ''; ?>">
                <div class="form-group">
                    <label for="password">New Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-primary">Change Password</button>
            </form>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Ensure passwords match
                if ($_POST['password'] !== $_POST['confirm_password']) {
                    echo "<div class='alert alert-danger mt-3'>Passwords do not match.</div>";
                } else {
                    // Database connection settings
                    $servername = "localhost";
                    $db_username = "root"; // Replace with your database username
                    $db_password = ""; // Replace with your database password
                    $dbname = "user"; // Replace with your database name

                    // Create connection
                    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $token = $_POST['token'];
                    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the new password

                    // Update user's password in the database
                    $update_stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_timestamp = NULL WHERE reset_token = ?");
                    $update_stmt->bind_param("ss", $new_password, $token);

                    if ($update_stmt->execute()) {
                        echo "<div class='alert alert-success mt-3'>Password updated successfully! <a href='index.php'>Go to Login</a></div>";
                    } else {
                        echo "<div class='alert alert-danger mt-3'>Error updating password: " . $conn->error . "</div>";
                    }

                    // Close statement and database connection
                    $update_stmt->close();
                    $conn->close();
                }
            }
            ?>
        </div>
        <div class="col-md-6 picture-container">
            <img src="https://www.freeiconspng.com/uploads/forgot-password-icon-27.png" alt="Background Image">
        </div>
    </div>
</div>
</body>
</html>
