<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "u675966424_umali"; // Replace with your MySQL username
$password = "Stephganda2003$"; // Replace with your MySQL password
$dbname = "u675966424_rentdb"; // Use your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if movie_id parameter is set
if (isset($_GET['movie_id'])) {
    $movie_id = $_GET['movie_id'];

    // Prepare SQL statement to delete record
    $sql_delete = "DELETE FROM movies WHERE movie_id = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("i", $movie_id);

    // Execute the delete statement
    if ($stmt->execute()) {
        // Success message for JavaScript alert
        echo '<script>alert("Record returned successfully"); window.location.href = "return.php";</script>';
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close statement
    $stmt->close();
} else {
    echo "No movie_id specified.";
}

// Close connection
$conn->close();
?>
