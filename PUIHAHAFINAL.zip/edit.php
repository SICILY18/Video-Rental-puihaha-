<?php
include_once 'db.php';

// Check if the movie_id is set and valid
if (isset($_GET['movie_id'])) {
    $movie_id = $_GET['movie_id'];

    // Fetch the movie details
    try {
        $query = "SELECT * FROM movies WHERE movie_id = :movie_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':movie_id', $movie_id, PDO::PARAM_STR);
        $stmt->execute();
        $movie = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$movie) {
            echo "Movie not found.";
            exit;
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    echo "Movie ID not specified.";
    exit;
}

// Handle form submission for updating the movie details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movie_id = $_POST['movie_id'];
    $movie_year = $_POST['movie_year'];
    $genre = $_POST['genre'];
    $image_link = $_POST['image_link'];

    try {
        // Corrected SQL statement by removing the extra comma before WHERE clause
        $updateQuery = "UPDATE movies SET movie_year = :movie_year, genre = :genre, image_link = :image_link WHERE movie_id = :movie_id";
        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->bindParam(':movie_id', $movie_id, PDO::PARAM_STR);
        $updateStmt->bindParam(':movie_year', $movie_year, PDO::PARAM_STR);
        $updateStmt->bindParam(':genre', $genre, PDO::PARAM_STR);
        $updateStmt->bindParam(':image_link', $image_link, PDO::PARAM_STR);

        if ($updateStmt->execute()) {
            // Redirect to rent.php with the movie_id as a query parameter
            header("Location: rent.php?movie_id=$movie_id");
            exit;
        } else {
            echo "Failed to update movie details.";
        }
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Movie</title>
    <link rel="stylesheet" href="style.css">
    <style>
          /* Styling for the edit form */
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        
        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }
        
        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }
        
        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }
        
        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }
        
        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }
        
        .nav .search-icon {
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }
        
        .search-box {
            position: absolute;
            top: calc(100% + 10px);
            right: 50%;
            transform: translateX(50%);
            width: 300px;
            max-width: calc(100% - 20px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.2s linear;
            z-index: 10;
        }
        
        .search-box .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            color: #4a98f7;
            transform: translateY(-50%);
        }
        
        .search-box input {
            height: 100%;
            width: 100%;
            border: none;
            outline: none;
            border-radius: 6px;
            background-color: #fff;
            padding: 0 15px 0 45px;
        }
        
        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }
        
        .rentcard {
            width: 100%;
            max-width: 500px;
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        
        .rentcard:hover {
            transform: translateY(-5px);
        }
        
        .rentcard-content {
            padding: 20px;
        }
        
        .rentcard-content form {
            display: grid;
            gap: 15px;
        }
        
        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
        }
        
        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .rentcard-content button:hover {
            background-color: #0056b3;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
        }
        
        .btn:hover {
            background-color: #0056b3;
        }
        
        .btn-danger {
            background-color: #dc3545;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .rent-button {
            background-color: #28a745;
        }
        
        .rent-button:hover {
            background-color: #218838;
        }
        
        .button-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }
        
        .button-container .btn {
            margin: 0 10px;
        }
        
        .button-container .btn-primary {
            order: 1;
        }
        
        .button-container .rent-button {
            order: 2;
        }
        
        .button-container .btn-danger {
            order: 3;
        }

        .edit-form {
            width: 100%;
            max-width: 500px;
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px;
            margin: auto;
            margin-top: 50px;
        }

        .edit-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .edit-form label {
            display: block;
            margin-bottom: 5px;
        }

        .edit-form input[type="text"],
        .edit-form input[type="number"],
        .edit-form input[type="url"],
        .edit-form fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
            margin-bottom: 15px;
        }

        .edit-form button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <i class="uil uil-times navCloseBtn"></i>
            <li><a href="homepage.html">Home</a></li>

            <li><a href="#">Rent A Movie</a></li>
            <li><a href="#">Return a Movie</a></li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Logout</a></li>
        </ul>
        <i class="uil uil-search search-icon" id="searchIcon"></i>
        <div class="search-box">
            <i class="uil uil-search search-icon"></i>
            <input type="text" placeholder="Search here..." />
        </div>
    </nav>
 <div class="edit-form">
        <h2>Edit Movie</h2>
        <form method="post" action="">
            <input type="hidden" name="movie_id" value="<?php echo htmlspecialchars($movie['movie_id']); ?>">
            <label for="movie_year">Year:</label>
            <input type="text" name="movie_year" id="movie_year" value="<?php echo htmlspecialchars($movie['movie_year']); ?>" required>

            <label for="genre">Genre:</label>
            <input type="text" name="genre" id="genre" value="<?php echo htmlspecialchars($movie['genre']); ?>" required>

            <label for="image_link">Image Link:</label>
            <input type="url" name="image_link" id="image_link" value="<?php echo htmlspecialchars($movie['image_link']); ?>" required>

            <button type="submit">Update Movie</button>
        </form>
    </div>
</body>
</html>