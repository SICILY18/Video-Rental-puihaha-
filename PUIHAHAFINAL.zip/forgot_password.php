<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection settings
    $servername = "localhost";
    $db_username = "root"; // Replace with your database username
    $db_password = ""; // Replace with your database password
    $dbname = "user"; // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = $_POST['username'];

    // Check if username exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate a unique token (can be timestamp + random string)
        $token = bin2hex(random_bytes(16)); // Example token generation

        // Store token in the database for the user
        $update_stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_timestamp = NOW() WHERE username = ?");
        $update_stmt->bind_param("ss", $token, $username);
        if ($update_stmt->execute()) {
            // Redirect to change password page with token in URL
            header("Location: change_password.php?token=" . urlencode($token));
            exit();
        } else {
            echo "<div class='alert alert-danger mt-3'>Error updating reset token: " . $conn->error . "</div>";
        }
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }

            25% {
                transform: translateX(-25%);
            }

            50% {
                transform: translateX(-50%);
            }

            75% {
                transform: translateX(-25%);
            }

            100% {
                transform: translateX(1);
            }
        }

        .login-container {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.1); /* Box shadow for depth */
            border-radius: 8px; /* Rounded corners for the container */
            padding: 30px; /* Padding inside the container */
            max-width: 700px; /* Limit container width */
            display: flex;
            align-items: center; /* Center items vertically */
        }

        .login-container .row {
            flex-wrap: nowrap; /* Prevent wrapping for side-by-side layout */
        }

        .login-container .info-container {
            flex: 1; /* Take up half of the container */
            padding: 20px; /* Padding inside the info container */
        }

        .login-container .info-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-container .info-container form {
            margin-top: 20px;
        }

        .login-container .picture-container {
            flex: 1; /* Take up half of the container */
        }

        .login-container .picture-container img {
            max-width: 100%;
            height: auto;
            border-top-right-radius: 8px; /* Rounded corner for image */
            border-bottom-right-radius: 8px; /* Rounded corner for image */
        }

        .login-container button[type="submit"] {
            width: 100%;
        }
    </style>
</head>
<body>
<div>
     <div class="wave"></div>
     <div class="wave"></div>
     <div class="wave"></div>
  </div>
<div class="container login-container mt-5">
    <div class="row">
        <div class="col-md-6 info-container">
            <h2>Forgot Password</h2>
            <form method="post" action="forgot_password.php">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <button type="submit" class="btn btn-primary">Reset Password</button>
            </form>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Database connection settings
                $servername = "localhost";
                $db_username = "root"; // Replace with your database username
                $db_password = ""; // Replace with your database password
                $dbname = "user"; // Replace with your database name

                // Create connection
                $conn = new mysqli($servername, $db_username, $db_password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $username = $_POST['username'];

                // Check if username exists in the database
                $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Generate a unique token (can be timestamp + random string)
                    $token = bin2hex(random_bytes(16)); // Example token generation

                    // Store token in the database for the user
                    $update_stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_timestamp = NOW() WHERE username = ?");
                    $update_stmt->bind_param("ss", $token, $username);
                    if ($update_stmt->execute()) {
                        // Redirect to change password page with token in URL
                        header("Location: change_password.php?token=" . urlencode($token));
                        exit();
                    }
                } else {
                    echo "<div class='alert alert-danger mt-3'>Username not found. Please check your username.</div>";
                }

                // Close statement and database connection
                $stmt->close();
                $conn->close();
            }
            ?>
        </div>
        <div class="col-md-6 picture-container">
            <img src="https://www.freeiconspng.com/uploads/forgot-password-icon-27.png" alt="Background Image">
        </div>
    </div>
</div>

</body>
</html>
