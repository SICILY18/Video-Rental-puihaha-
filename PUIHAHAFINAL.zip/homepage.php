<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" href="style.css" />
    <!-- Unicons CSS -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <script src="script.js" defer></script>
    
    <style>
        /* Google Fonts - Poppins */
        
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        
        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }
        
        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }
        
        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }
        
        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }
        
        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }
        
        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }
        
        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }
        
        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }
        
        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }
        
        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
            margin-top: 80px;
            /* Adjusted to avoid overlapping with nav */
        }
        
        .card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 300px;
            margin: 20px;
            transition: transform 0.2s, background 0.2s;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .card:hover {
            transform: scale(1.05);
            background: rgba(255, 255, 255, 0.2);
        }
        
        .card img {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .card-content {
            padding: 15px;
        }
        
        .card-title {
            font-size: 1.5em;
            margin-bottom: 10px;
        }
        
        .card-description {
            font-size: 1em;
            color: #555;
        }
        /* Media Queries */
        
        @media screen and (max-width: 1160px) {
            .nav {
                padding: 15px 100px;
            }
            .nav .search-box {
                right: 150px;
            }
        }
        
        @media screen and (max-width: 950px) {
            .nav {
                padding: 15px 50px;
            }
        }
        
        @media screen and (max-width: 768px) {
            .nav {
                padding: 15px 20px;
            }
            .nav .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                height: 100%;
                max-width: 280px;
                width: 100%;
                padding-top: 100px;
                row-gap: 30px;
                flex-direction: column;
                background-color: #11101d;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                transition: all 0.4s ease;
                z-index: 100;
            }
            .nav.openNav .nav-links {
                left: 0;
            }
            .nav .navOpenBtn {
                display: block;
                color: #fff;
                font-size: 20px;
                cursor: pointer;
            }
            .nav .navCloseBtn {
                display: block;
                position: absolute;
                top: 20px;
                right: 20px;
                color: #fff;
                font-size: 20px;
                cursor: pointer;
            }
            .nav .search-box {
                top: calc(100% + 10px);
                max-width: calc(100% - 20px);
                right: 50%;
                transform: translateX(50%);
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
        }
    </style>
</head>

<body>
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">

            <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
    </nav>
    <!-- end of navbar -->
    <div class="card-container">
        <div class="card">
            <img src="https://i.pinimg.com/564x/5f/eb/51/5feb51f8d1f4b72e84fcb90dde8f5080.jpg" alt="Card Image">
            <div class="card-content">
                <h2 class="card-title">Extensive Collection</h2>
                <p class="card-description">Browse through our extensive collection of movies and TV shows. Find your favorite genres and discover new titles.</p>
            </div>
        </div>

        <div class="card">
            <img src="https://i.pinimg.com/564x/db/0f/bc/db0fbcf8256f77884ef9694413154f0c.jpg" alt="Card Image">
            <div class="card-content">
                <h2 class="card-title">Easy Rentals</h2>
                <p class="card-description">Our rental process is quick and easy. Rent your favorite videos with just a few clicks and enjoy them at your convenience.</p>
            </div>
        </div>

        <div class="card">
            <img src="https://i.pinimg.com/564x/a3/f4/10/a3f4109aba040cefc6def1ed137869ab.jpg" alt="Card Image">
            <div class="card-content">
                <h2 class="card-title">Affordable Prices</h2>
                <p class="card-description">Enjoy our video rentals at affordable prices. We offer competitive rates and various membership plans to suit your needs.</p>
            </div>
        </div>
    </div>

    <script>
        const nav = document.querySelector(".nav"),
            searchIcon = document.querySelector("#searchIcon"),
            navOpenBtn = document.querySelector(".navOpenBtn"),
            navCloseBtn = document.querySelector(".navCloseBtn");

        searchIcon.addEventListener("click", () => {
            nav.classList.toggle("openSearch");
            nav.classList.remove("openNav");
            if (nav.classList.contains("openSearch")) {
                return searchIcon.classList.replace("uil-search", "uil-times");
            }
            searchIcon.classList.replace("uil-times", "uil-search");
        });

        navOpenBtn.addEventListener("click", () => {
            nav.classList.add("openNav");
            nav.classList.remove("openSearch");
            searchIcon.classList.replace("uil-times", "uil-search");
        });

        navCloseBtn.addEventListener("click", () => {
            nav.classList.remove("openNav");
        });

        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
</body>

</html>