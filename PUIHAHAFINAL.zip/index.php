<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
        }

            25% {
            transform: translateX(-25%);
        }

        50% {
            transform: translateX(-50%);
        }

        75% {
            transform: translateX(-25%);
        }

        100% {
            transform: translateX(1);
        }
        }

        .login-container {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.1); /* Box shadow for depth */
            border-radius: 8px; /* Rounded corners for the container */
            padding: 30px; /* Padding inside the container */
            max-width: 700px; /* Limit container width */
            display: flex;
            flex-direction: row;
            overflow: hidden;
        }

        .login-container .row {
            align-items: center; /* Center align items vertically */
        }

        .login-container .form-group {
            margin-bottom: 20px; /* Space between form fields */
        }

        .login-container img {
            max-width: 100%;
            height: auto;
            border-top-right-radius: 8px; /* Rounded corner for image */
            border-bottom-right-radius: 8px; /* Rounded corner for image */
        }

        .password-recovery-link {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div>
     <div class="wave"></div>
     <div class="wave"></div>
     <div class="wave"></div>
  </div>
    <div class="container login-container">
        <div class="row">
            <div class="col-md-6">
                <h2>Log In</h2>
                <form id="signInForm" method="POST" action="index.php">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Log in</button>
                </form>
                <div class="password-recovery-link">
                    <a href="forgot_password.php">Forgot your password?</a>
                </div>
                <p class="mt-3">Don't have an account? <a href="signin.php" class="btn btn-secondary">Sign Up</a></p>
            </div>
            <div class="col-md-6">
                <img src="https://crewscontrol.com/wp-content/uploads/2019/07/vanilla-bear-films-Wnly2mV4YKw-unsplash.jpg" alt="Background Image">
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection settings
        $servername = "localhost";
        $db_username = "u675966424_yapi"; // Replace with your database username
        $db_password = "Cieloganda2003$"; // Replace with your database password
        $dbname = "u675966424_user"; // Replace with your database name

        // Create connection
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $username = $_POST['username'];
        $password = $_POST['password'];

        // Prepare SQL statement to select user data from 'users' table
        $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();
            
            if (password_verify($password, $hashed_password)) {
                echo "<script>alert('Login successful! Redirecting to the main page.'); window.location.replace('homepage.php');</script>"; //change welcome.php sa new homepage
            } else {
                echo "<script>alert('Login failed. Please check your username and password.');</script>";
            }
        } else {
            echo "<script>alert('Login failed. Please check your username and password.');</script>";
        }

        // Close statement and database connection
        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>
