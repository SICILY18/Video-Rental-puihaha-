<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <link rel="stylesheet" href="styles.css">
    <style>
	        /* Google Fonts - Poppins */
        
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        
        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }
        
        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }
        
        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }
        
        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }
        
        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }
        
    /* Existing styles... */

.nav {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 15px 200px;
    background: #E01A4F;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 1000; /* Adjusted z-index to ensure it's above other elements */
}

/* Existing styles... */

        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }
        
        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }
        
        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }
        
        
        /* Add these styles to adjust the layout and spacing */
        
        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }
        
        .rentcard {
            width: 100%;
            max-width: 500px;
            /* Adjust the maximum width as needed */
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        
        .rentcard:hover {
            transform: translateY(-5px);
        }
        
        .rentcard-content {
            padding: 20px;
        }
        
        .rentcard-content form {
            display: grid;
            gap: 15px;
            /* Adjust the gap between elements */
        }
        
        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
            /* Add margin below each label */
        }
        
        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            /* Add margin at the top of fieldset */
        }
        
        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .rentcard-content button:hover {
            background-color: #0056b3;
        }
        /* Global styles and imports remain the same */
        /* Adjustments for responsiveness */
        
        @media (max-width: 768px) {
            .nav {
                padding: 15px 20px;
                /* Adjust padding for smaller screens */
            }
            .nav .nav-links {
                margin-right: 20px;
                /* Reduce margin for smaller screens */
            }
            .rentcont {
                padding: 10px;
            }
            .rentcard {
                max-width: 100%;
            }
            .rentcard-content form {
                display: flex;
                flex-direction: column;
            }
            .rentcard-content label {
                margin-bottom: 10px;
            }
            .rentcard-content input[type="text"],
            .rentcard-content input[type="number"],
            .rentcard-content input[type="url"],
            .rentcard-content fieldset {
                width: 100%;
                padding: 8px;
                font-size: 0.9rem;
            }
            .rentcard-content button {
                padding: 12px 20px;
            }
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 75vh;
        }
        .container {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .form-group {
            margin-bottom: 1px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"] {
            width: 100%;
            padding: 1px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-group input[type="number"] {
            width: calc(50% - 5px);
        }
        .form-group select {
            width: calc(50% + 5px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
           .form-group .card-group {
        display: flex;
        gap: 10px;
        align-items: center; /* Center align items vertically */
    }

    .form-group .card-group div {
        flex: 1; /* Each input field takes equal space */
    }

    .form-group .card-group input {
        width: 100%; /* Full width for input fields */
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        font-size: 1rem; /* Adjust font size as needed */
    }

    .form-group .card-group label {
        margin-bottom: 5px; /* Add margin below each label */
    }

    .form-group .card-group input[type="number"] {
        width: 100%; /* Full width for number inputs */
    }

    .form-group .card-group input[type="text"] {
        width: 100%; /* Full width for text inputs */
    }

    .form-group .card-group input[type="text"]:last-child {
        margin-left: 10px; /* Add margin between fields */
    }

    .form-group .card-group input[type="text"]:first-child {
        margin-right: 10px; /* Add margin between fields */
    }

    .form-group .card-group input[type="number"] {
        width: 100%; /* Full width for number inputs */
    }
        .form-group .paypal-info input[type="date"] {
            width: calc(50% + 5px);
        }
        .form-group .paypal-info .card-group {
            display: flex;
            gap: 10px;
        }
        .form-group .paypal-info .card-group input {
            flex: 1;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-group .paypal-info .card-group select {
            flex: 1;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-group .paypal-info .card-group input[type="number"] {
            width: calc(25% - 5px);
        }
        .form-group .paypal-info .card-group input[type="number"] {
            width: calc(50% - 5px);
        }
        .form-group .paypal-info .card-group select {
            width: calc(50% + 5px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-group .paypal-info .card-group input[type="number"] {
            width: calc(25% - 5px);
        }
        .form-group .paypal-info .card-group input[type="tel"] {
            width: calc(25% + 5px);
        }
    </style>
</head>
<body>

<nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <i class="uil uil-times navCloseBtn"></i>
           <li><a href="homepage.php">Home</a></li>
           <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
    </nav>
	
  <body>
    <div class="container">
        <h2>Payment Details</h2>
        <form id="payment-form" action="process_payment.php" method="POST">
            <!-- Billing Address -->
            <div class="form-group">
                <label for="fullname">Full Name:</label>
                <input type="text" id="fullname" name="fullname" placeholder="Enter full name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter email" required>
            </div>
            <div class="form-group">
                <label for="country">Country:</label>
                <input type="text" id="country" name="country" placeholder="Enter country" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" placeholder="Enter address" required>
            </div>
            <div class="form-group">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" placeholder="Enter city" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" placeholder="Enter phone number" required>
            </div>
            <div class="form-group">
                <label for="zipcode">Zip Code:</label>
                <input type="text" id="zipcode" name="zipcode" placeholder="Enter zip code" required>
            </div>

            <!-- Payment Method -->
            <div class="form-group">
                <label for="payment-method">Payment Method:</label><br>
                <input type="radio" id="credit-card" name="payment-method" value="Credit Card">
                <label for="credit-card">Credit Card</label><br>
                <input type="radio" id="paypal" name="payment-method" value="PayPal">
                <label for="paypal">PayPal</label>
            </div>

            <!-- PayPal Information -->
            <div class="form-group paypal-info" id="paypal-info">
                <h3>PayPal Information</h3>
                <div class="form-group">
                    <label for="card-name">Name on Card:</label>
                    <input type="text" id="card-name" name="card-name" placeholder="Enter name on card">
                </div>
                <div class="form-group">
                    <label for="card-number">Credit Card Number:</label>
                    <input type="text" id="card-number" name="card-number" placeholder="Enter credit card number">
                </div>
                <div class="form-group card-group">
                    <div>
                        <label for="exp-month">Expiration Month:</label>
                        <input type="number" id="exp-month" name="exp-month" placeholder="MM" min="1" max="12">
                    </div>
                    <div>
                        <label for="exp-year">Expiration Year:</label>
                        <input type="number" id="exp-year" name="exp-year" placeholder="YYYY" min="2024" max="2050">
                    </div>
                    <div>
                        <label for="cvv">CVV:</label>
                        <input type="text" id="cvv" name="cvv" placeholder="Enter CVV" minlength="3" maxlength="4" pattern="[0-9]{3,4}" required>
                    </div>
                </div>
            </div>

            <button type="submit" class="submit-btn">Submit Payment</button>
        </form>
    </div>

  <script>
        const paymentMethodRadio = document.querySelectorAll('input[name="payment-method"]');
        const paypalInfo = document.getElementById('paypal-info');

        paymentMethodRadio.forEach(radio => {
            radio.addEventListener('change', function() {
                if (radio.value === 'PayPal') {
                    paypalInfo.style.display = 'block';
                } else {
                    paypalInfo.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>