<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmation</title>
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Add styles for the receipt */
		  /* Google Fonts - Poppins */
        
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        
        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }
        
        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }
        
        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }
        
        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }
        
        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }
        
        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }
        
        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }
        
        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }
        
        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }
        
        .nav .search-icon {
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }
        
        .search-box {
            position: absolute;
            top: calc(100% + 10px);
            right: 50%;
            transform: translateX(50%);
            width: 300px;
            max-width: calc(100% - 20px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.2s linear;
            z-index: 10;
        }
        
        .search-box .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            color: #4a98f7;
            transform: translateY(-50%);
        }
        
        .search-box input {
            height: 100%;
            width: 100%;
            border: none;
            outline: none;
            border-radius: 6px;
            background-color: #fff;
            padding: 0 15px 0 45px;
        }
        /* Add these styles to adjust the layout and spacing */
        
        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }
        
        .rentcard {
            width: 100%;
            max-width: 500px;
            /* Adjust the maximum width as needed */
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        
        .rentcard:hover {
            transform: translateY(-5px);
        }
        
        .rentcard-content {
            padding: 20px;
        }
        
        .rentcard-content form {
            display: grid;
            gap: 15px;
            /* Adjust the gap between elements */
        }
        
        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
            /* Add margin below each label */
        }
        
        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            /* Add margin at the top of fieldset */
        }
        
        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .rentcard-content button:hover {
            background-color: #0056b3;
        }
        /* Global styles and imports remain the same */
        /* Adjustments for responsiveness */
        
        @media (max-width: 768px) {
            .nav {
                padding: 15px 20px;
                /* Adjust padding for smaller screens */
            }
            .nav .nav-links {
                margin-right: 20px;
                /* Reduce margin for smaller screens */
            }
            .rentcont {
                padding: 10px;
            }
            .rentcard {
                max-width: 100%;
            }
            .rentcard-content form {
                display: flex;
                flex-direction: column;
            }
            .rentcard-content label {
                margin-bottom: 10px;
            }
            .rentcard-content input[type="text"],
            .rentcard-content input[type="number"],
            .rentcard-content input[type="url"],
            .rentcard-content fieldset {
                width: 100%;
                padding: 8px;
                font-size: 0.9rem;
            }
            .rentcard-content button {
                padding: 12px 20px;
            }
        }
    
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .receipt {
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .receipt h2 {
            margin-bottom: 10px;
        }
        .receipt p {
            margin-bottom: 5px;
        }
        .receipt .amount {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .receipt .message {
            margin-top: 20px;
        }
        .btn {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
		.message {
            text-align: center; /* Center align the message */
            margin-bottom: 20px; /* Add some margin for spacing */
        }
        .btn-group {
            display: flex;
            justify-content: space-between;
        }
        .btn {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .btn.return {
            margin-left: auto; /* Moves the Return Movie button to the right */
        }
    </style>
</head>
<body>
<nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <i class="uil uil-times navCloseBtn"></i>
            <li><a href="homepage.php">Home</a></li>
            <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
        <i class="uil uil-search search-icon" id="searchIcon"></i>
        <div class="search-box">
            <i class="uil uil-search search-icon"></i>
            <input type="text" placeholder="Search here..." />
        </div>
    </nav>
	
      <div class="container">
        <div class="receipt">
            <h2>Payment Confirmation</h2>
            <p>Your payment of PHP 300 has been confirmed.</p>
            <p class="amount">Amount: PHP 300</p>
        </div>
        <div class="message">
            <p>Thank you for your payment.</p>
        </div>
        <div class="btn-group">
            <a href="homepage.php" class="btn">Back to Homepage</a>
            <a href="return.php" class="btn return">Return a Movie</a>
        </div>
    </div>
</body>
</html>