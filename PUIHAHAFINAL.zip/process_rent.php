<!-- process_rent.php -->

<?php
include_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form submission to rent movie
    $movie_id = $_POST['movie_id'];
    $rental_date = $_POST['rental_date'];

    // Example SQL query to insert rental record into database
    $query = "INSERT INTO rentals (movie_id, rental_date) VALUES (:movie_id, :rental_date)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':movie_id', $movie_id, PDO::PARAM_INT);
    $stmt->bindParam(':rental_date', $rental_date);

    if ($stmt->execute()) {
        // Rental record inserted successfully
        echo "<script>alert('Movie rented successfully!');</script>";
        echo "<script>window.location.href = 'homepage.html';</script>";
    } else {
        echo "Error renting movie.";
    }
}
?>
