<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "u675966424_umali"; // Replace with your MySQL username
$password = "Stephganda2003$"; // Replace with your MySQL password
$dbname = "u675966424_rentdb"; // Use your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch user data
$sql_rentdb = "SELECT movie_id, movie_year, genre, image_link FROM movies ORDER BY id DESC LIMIT 1";
$result_rentdb = $conn->query($sql_rentdb);

$no_movie_found = false; // Initialize flag

if ($result_rentdb) {
    if ($result_rentdb->num_rows > 0) {
        // Output data of the most recent user
        $row_rentdb = $result_rentdb->fetch_assoc();
        $movie_year = $row_rentdb["movie_year"];
        $movie_id = $row_rentdb["movie_id"];
        $genre = $row_rentdb["genre"];
        $image_link = $row_rentdb["image_link"];
    } else {
        $no_movie_found = true; // Set flag if no movie found
    }
} else {
    echo "Error: " . $conn->error;
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent a Movie</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <link rel="stylesheet" href="style.css" />
    <!-- Unicons CSS -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <style>
        /* Google Fonts - Poppins */
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }

        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }

        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }

        .nav .search-icon {
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }

        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }

        .rentcard {
            width: 100%;
            max-width: 500px;
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .rentcard:hover {
            transform: translateY(-5px);
        }

        .rentcard-content {
            padding: 20px;
        }

        .rentcard-content form {
            display: grid;
            gap: 15px;
        }

        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
        }

        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .rentcard-content button:hover {
            background-color: #0056b3;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .rent-button {
            background-color: #28a745;
        }

        .rent-button:hover {
            background-color: #218838;
        }

        @media (max-width: 768px) {
            /* Add responsive styles if needed */
        }
    </style>
</head>
<body>
    <nav class="nav">
        <i class="uil uil-bars navOpenBtn"></i>
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <li><a href="homepage.php">Home</a></li>
            <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
    </nav>
    <div class="rentcont">
        <?php if ($no_movie_found): ?>
            <h2>No available movie to rent</h2>
            <a href="homepage.php" class="btn btn-primary">Go to Homepage</a>
        <?php else: ?>
            <div class="rentcard">
                <div class="rentcard-content">
                    <h2><?php echo htmlspecialchars($movie_id); ?></h2>
                    <p>Year: <?php echo htmlspecialchars($movie_year); ?></p>
                    <p>Genre: <?php echo htmlspecialchars($genre); ?></p>
                    <p class="price-info">Price: PHP 300</p>
                    <?php if (isset($image_link)): ?>
                        <img src="<?php echo htmlspecialchars($image_link); ?>" alt="<?php echo htmlspecialchars($movie_id); ?>" style="max-width: 100%; height: auto;">
                    <?php endif; ?>
                    <div class="button-container">
                        <a href="edit.php?movie_id=<?php echo $movie_id; ?>" class="btn btn-primary">Edit</a>
                        <a href="payment.php" class="btn rent-button">Rent Now</a>
                        <a href="delete.php?movie_id=<?php echo $movie_id; ?>" class="btn btn-danger">Remove</a>
                    </div>
                </div>
            </div>
            <a href="add.php" class="btn btn-primary">Back to Movie List</a>
        <?php endif; ?>
    </div>
</body>
</html>
