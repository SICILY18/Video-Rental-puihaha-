<?php
include_once 'db.php';

// Function to format date nicely
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

try {
    // Query to fetch rental history
    $query = "SELECT rentals.id, movies.movie_id, movies.movie_year, movies.genre, movies.image_link, rentals.rental_date, rentals.return_date, DATEDIFF(return_date, rental_date) AS days_rented
              FROM rentals
              INNER JOIN movies ON rentals.movie_id = movies.id
              ORDER BY rentals.id DESC";
    $stmt = $pdo->query($query);
    $rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental History</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="nav">
        <!-- Your navigation bar code here -->
    </nav>
    
    <div class="rentcont">
        <?php foreach ($rentals as $rental): ?>
            <div class="rentcard">
                <div class="rentcard-content">
                    <h2><?php echo htmlspecialchars($rental['movie_id']); ?></h2>
                    <p>Year: <?php echo htmlspecialchars($rental['movie_year']); ?></p>
                    <p>Genre: <?php echo htmlspecialchars($rental['genre']); ?></p>
                    <p>Rental Date: <?php echo formatDate($rental['rental_date']); ?></p>
                    <?php if ($rental['return_date']): ?>
                        <p>Return Date: <?php echo formatDate($rental['return_date']); ?></p>
                        <p>Days Rented: <?php echo htmlspecialchars($rental['days_rented']); ?></p>
                        <!-- Calculate and display late fees if applicable -->
                        <?php
                        $days_rented = (int)$rental['days_rented'];
                        $late_fee_per_day = 1.5; // Example late fee rate per day
                        $late_fees = 0;
                        
                        if ($days_rented > 3) {
                            $late_days = $days_rented - 3;
                            $late_fees = $late_days * $late_fee_per_day;
                            echo "<p>Late Fees: $" . number_format($late_fees, 2) . "</p>";
                        }
                        ?>
                    <?php else: ?>
                        <p>Status: Not Returned Yet</p>
                    <?php endif; ?>
                    <?php if (isset($rental['image_link'])): ?>
                        <img src="<?php echo htmlspecialchars($rental['image_link']); ?>" alt="<?php echo htmlspecialchars($rental['movie_id']); ?>" style="max-width: 100%; height: auto;">
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        
        <!-- Link back to main page -->
        <a href="homepage.html" class="btn btn-primary">Back to Home</a>
    </div>
</body>
</html>