<?php
session_start();

// Database configuration
$host = 'localhost';
$dbname = 'u675966424_rentdb'; // Update database name here
$username = 'u675966424_umali'; // Update username if different
$password = 'Stephganda2003$'; // Update password if set

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch user data
$sql_rentdb = "SELECT movie_id, movie_year, genre, image_link FROM movies ORDER BY id DESC LIMIT 1";
$result_rentdb = $conn->query($sql_rentdb);

// Initialize variables
$movie_id = $movie_year = $genre = $image_link = '';

// Check if query executed successfully
if ($result_rentdb) {
    // Fetch the movie details
    if ($result_rentdb->num_rows > 0) {
        $row_rentdb = $result_rentdb->fetch_assoc();
        $movie_id = $row_rentdb["movie_id"];
        $movie_year = $row_rentdb["movie_year"];
        $genre = $row_rentdb["genre"];
        $image_link = $row_rentdb["image_link"];
    } else {
        // No movie found in database
        $no_movie_found = true;
    }
} else {
    die("Query failed: " . $conn->error);
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return a Movie</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <link rel="stylesheet" href="style.css" />
    <!-- Unicons CSS -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <style>
        /* Google Fonts - Poppins */
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap");
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background: linear-gradient(315deg, #7B8CDE 3%, #E01A4F 38%, #F9C22E 68%, #ADF7B6 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 200px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }

        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
            margin-right: 100px;
        }

        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }

        .nav .search-icon {
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }


        .rentcont {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
        }

        .rentcard {
            width: 100%;
            max-width: 500px;
            background-color: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .rentcard:hover {
            transform: translateY(-5px);
        }

        .rentcard-content {
            padding: 20px;
        }

        .rentcard-content form {
            display: grid;
            gap: 15px;
        }

        .rentcard-content label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .rentcard-content input[type="text"],
        .rentcard-content input[type="number"],
        .rentcard-content input[type="url"],
        .rentcard-content fieldset {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        .rentcard-content fieldset {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
        }

        .rentcard-content button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .rentcard-content button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .nav {
                padding: 15px 20px;
            }
            .nav .nav-links {
                margin-right: 20px;
            }
            .rentcont {
                padding: 10px;
            }
            .rentcard {
                max-width: 100%;
            }
            .rentcard-content form {
                display: flex;
                flex-direction: column;
            }
            .rentcard-content label {
                margin-bottom: 10px;
            }
            .rentcard-content input[type="text"],
            .rentcard-content input[type="number"],
            .rentcard-content input[type="url"],
            .rentcard-content fieldset {
                width: 100%;
                padding: 8px;
                font-size: 0.9rem;
            }
            .rentcard-content button {
                padding: 12px 20px;
            } 
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .rent-button {
            background-color: #28a745;
        }

        .rent-button:hover {
            background-color: #218838;
        }

        @media (max-width: 768px) {
            /* Add responsive styles if needed */
        }
    </style>
</head>
<body>
    <nav class="nav">
        <a href="#" class="logo">Puihaha Video Production</a>
        <ul class="nav-links">
            <li><a href="homepage.php">Home</a></li>
            <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
        </ul>
    </nav>
    <div class="rentcont">
        <?php if (isset($no_movie_found) && $no_movie_found): ?>
            <h2>No movie to return</h2>
        <?php else: ?>
            <div class="rentcard">
                <div class="rentcard-content">
                    <h2><?php echo htmlspecialchars($movie_id); ?></h2>
                    <p>Year: <?php echo htmlspecialchars($movie_year); ?></p>
                    <p>Genre: <?php echo htmlspecialchars($genre); ?></p>
                    <?php if (!empty($image_link)): ?>
                        <img src="<?php echo htmlspecialchars($image_link); ?>" alt="<?php echo htmlspecialchars($movie_id); ?>" style="max-width: 100%; height: auto;">
                    <?php endif; ?>
                    <div class="button-container">
                        <a href="delete1.php?movie_id=<?php echo $movie_id; ?>" class="btn btn-danger">Return</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <a href="add.php" class="btn btn-primary">Back to Movie List</a>
    </div>
</body>
</html>
