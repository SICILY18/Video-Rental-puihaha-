<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
        }

            25% {
            transform: translateX(-25%);
        }

        50% {
            transform: translateX(-50%);
        }

        75% {
            transform: translateX(-25%);
        }

        100% {
            transform: translateX(1);
        }
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 30px;
            max-width: 900px; /* Increased width for larger container */
            width: 100%;
            display: flex;
            flex-direction: row;
            overflow: hidden; /* Ensure the image does not overflow its container */
        }

        .form-container .form-column {
            flex: 1;
            padding-right: 30px;
        }

        .form-container .image-column {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .image-container {
            max-width: 100%;
            height: 100%;
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
            overflow: hidden;
        }

        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover; /* Ensure the image covers its container */
        }
    </style>
</head>
<body>
<div>
     <div class="wave"></div>
     <div class="wave"></div>
     <div class="wave"></div>
</div>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3 form-container">
            <div class="form-column">
                <h2>Sign Up</h2>
                <form method="post" action="signin.php">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="first_name">First Name:</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name:</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Sign Up</button>
                </form>
            </div>
            <div class="image-column">
                <div class="image-container">
                    <img src="https://img.freepik.com/premium-photo/collection-different-types-camera-equipment_960782-31028.jpg?size=626&ext=jpg&ga=GA1.1.1826414947.1699660800&semt=ais" alt="Background Image">
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Database connection settings
$servername = "localhost";
        $db_username = "u675966424_yapi"; // Replace with your database username
        $db_password = "Cieloganda2003$"; // Replace with your database password
        $dbname = "u675966424_user"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $last_name = $_POST['last_name'];
    $first_name = $_POST['first_name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

    // Prepare SQL statement to insert user data into 'users' table
    $stmt = $conn->prepare("INSERT INTO users (last_name, first_name, email, username, password) VALUES (?, ?, ?, ?, ?)");

    // Bind parameters to the SQL statement
    $stmt->bind_param("sssss", $last_name, $first_name, $email, $username, $password);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        echo "<script>alert('User registered successfully!'); window.location.replace('index.php');</script>";
        // Redirect to index.php after successful registration
        // header("Location: index.php");
        // exit(); // Ensure script stops executing after redirection
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and database connection
    $stmt->close();
}

// Close database connection outside of the form submission handling
$conn->close();
?>
</body>
</html>
