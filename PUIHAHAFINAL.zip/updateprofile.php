<?php
session_start();

// Database configuration and connection
// Database configuration
 $servername = "localhost";
        $db_username = "u675966424_yapi"; // Replace with your database username
        $db_password = "Cieloganda2003$"; // Replace with your database password
        $dbname = "u675966424_user"; // Replace with your database name

        // Create connection
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store updated data and error messages
$email = "";
$firstName = "";
$lastName = "";
$username = "";
$emailError = ""; // Variable to store email validation error message

// Fetch current user data to pre-fill the form
$sql = "SELECT first_name, last_name, email, username FROM users ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $email = $row["email"];
    $firstName = $row["first_name"];
    $lastName = $row["last_name"];
    $username = $row["username"];
} else {
    echo "No user found.";
}

// Handle form submission to update user data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data (example)
    $email = $_POST["email"];
    $firstName = $_POST["first_name"];
    $lastName = $_POST["last_name"];
    $username = $_POST["username"];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = "Invalid email format. Please enter a valid Email Address";
    } else {
        // Update user data in the database
        $sql_update = "UPDATE users SET first_name=?, last_name=?, email=? WHERE username=?";
        $stmt = $conn->prepare($sql_update);

        if ($stmt === false) {
            echo "Error preparing statement: " . $conn->error;
        }

        $stmt->bind_param("ssss", $firstName, $lastName, $email, $username);

        if ($stmt->execute()) {
            // Set success message in session variable
            $_SESSION['update_success'] = true;
            // Redirect to view profile page after successful update
            header("Location: viewprof.php");
            exit();
        } else {
            echo "Error updating record: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Close connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            position: relative;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgba(255, 255, 255, 0.25);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }

        .container {
            background: rgba(255, 255, 255, 0.15); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 900px;
            width: 90%;
            margin: 120px 20px 20px; /* Added top margin to create space from navbar */
            text-align: center;
            backdrop-filter: blur(10px); /* Blur effect for glass effect */
            -webkit-backdrop-filter: blur(10px); /* For Safari */
            position: relative;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
            text-align: left; /* Align text left */
        }

        .profile-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px 0;
        }

        .profile {
            text-align: center;
            margin: 20px;
            width: 100%; /* Adjust width as needed */
            max-width: 400px; /* Max width for responsiveness */
            padding: 30px;
            border-radius: 10px;
            -webkit-backdrop-filter: blur(5px); /* For Safari */
        }

        .profile img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ccc;
            margin-bottom: 20px;
        }

        .profile h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }

        .profile p {
            color: #666;
            margin-bottom: 15px;
            font-size: 0.9em;
        }

        .profile input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            font-size: 0.9em;
            outline: none;
            background-color: #f0f0f0; /* Light grey background */
        }

        .profile input[type="text"]:focus {
            background-color: #e0e0e0; /* Lighter grey background on focus */
        }

        .error-message {
            color: red;
            font-size: 0.8em;
            margin-top: 5px;
        }

        .update-button {
            background-color: #007BFF; /* Blue background */
            color: #fff; /* White text */
            border: none; /* Remove default border */
            padding: 10px 20px; /* Padding for size */
            border-radius: 30px; /* More rounded corners */
            font-size: 16px; /* Font size */
            font-weight: 600; /* Slightly bolder text */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth transitions */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); /* More prominent shadow */
        }

        .update-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: translateY(-2px); /* Lift effect on hover */
        }

        .update-button:active {
            background-color: #004494; /* Even darker blue on click */
            transform: translateY(0); /* Return to normal position on click */
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Update Profile</h1>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="profile-container">
            <div class="profile">
                <img src="https://icons.veryicon.com/png/o/miscellaneous/standard/avatar-15.png" alt="Profile Picture">
                <h2><?php echo htmlspecialchars($username); ?></h2>
                <p><input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>" placeholder="Email"></p>
                <?php if (!empty($emailError)) : ?>
                    <p class="error-message"><?php echo $emailError; ?></p>
                <?php endif; ?>
                <p><input type="text" name="first_name" value="<?php echo htmlspecialchars($firstName); ?>" placeholder="First Name"></p>
                <p><input type="text" name="last_name" value="<?php echo htmlspecialchars($lastName); ?>" placeholder="Last Name"></p>
                <!-- Hidden field to pass username for update -->
                <input type="hidden" name="username" value="<?php echo htmlspecialchars($username); ?>">
                <!-- Add more user details as needed -->
                <button type="submit" class="update-button">Update Profile</button>
            </div>
        </div>
    </form>
</div>

<!-- Include any necessary JavaScript -->


</body>
</html>
