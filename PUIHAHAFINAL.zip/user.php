<?php
// Database connection settings - Update these with your hosting server details
$servername = "your_server_name"; // Replace with your server name (e.g., example.com)
$username = "your_database_username"; // Replace with your database username
$password = "your_database_password"; // Replace with your database password
$dbname = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action == 'create') {
        // Handle user registration (if needed)
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $sql = "INSERT INTO users (last_name, first_name, username, password, email) VALUES ('$last_name', '$first_name', '$username', '$password', $email)";
        $conn->query($sql);
    } elseif ($action == 'read') {
        // Handle reading users (if needed)
        $sql = "SELECT * FROM users";
        $result = $conn->query($sql);
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        echo json_encode($users);
    } elseif ($action == 'update') {
        // Handle user information update (if needed)
        $id = $_POST['id'];
        $last_name = $_POST['last_name'];
        $first_name = $_POST['first_name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $sql = "UPDATE users SET last_name='$last_name', first_name='$first_name', username='$username', password='$password', email=$email WHERE id=$id";
        $conn->query($sql);
    } elseif ($action == 'authenticate') {
        // Handle authentication based on last name
        $last_name = $_POST['last_name'];
        $sql = "SELECT * FROM users WHERE last_name = '$last_name'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo 'success';
        } else {
            echo 'failure';
        }
    }
}

$conn->close();
?>
