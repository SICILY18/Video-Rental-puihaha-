<?php
session_start();

// Database configuration
 $servername = "localhost";
        $db_username = "u675966424_yapi"; // Replace with your database username
        $db_password = "Cieloganda2003$"; // Replace with your database password
        $dbname = "u675966424_user"; // Replace with your database name

        // Create connection
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch user data
$sql_user = "SELECT first_name, last_name, email, username FROM users ORDER BY id DESC LIMIT 1";
$result_user = $conn->query($sql_user);

if ($result_user->num_rows > 0) {
    // Output data of the most recent user
    $row_user = $result_user->fetch_assoc();
    $email = $row_user["email"];
    $name = $row_user["first_name"] . " " . $row_user["last_name"];
    $username = $row_user["username"];
} else {
    echo "No user found.";
}

// Query to fetch rental history data
$sql_rentals = "SELECT movie_id, rental_date FROM rentals WHERE id = ? ORDER BY rental_date DESC";
$stmt = $conn->prepare($sql_rentals);
$id = 1; // Replace with the actual user ID (you may fetch this dynamically based on session)
$stmt->bind_param("i", $id);
$stmt->execute();
$result_rentals = $stmt->get_result();

$rentals = array();
if ($result_rentals->num_rows > 0) {
    while ($row_rentals = $result_rentals->fetch_assoc()) {
        $rentals[] = $row_rentals;
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script>
        function confirmLogout(event) {
            event.preventDefault(); // Prevent the default link behavior
            var userConfirmed = confirm("Are you sure you want to logout?");
            if (userConfirmed) {
                window.location.href = 'logout.php?confirm=yes'; // Redirect to logout.php with confirmation
            }
        }
    </script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(315deg, rgba(101,0,94,1) 3%, rgba(60,132,206,1) 38%, rgba(48,238,226,1) 68%, rgba(255,25,25,1) 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            position: relative;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgba(255, 255, 255, 0.25);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }
            25% {
                transform: translateX(-25%);
            }
            50% {
                transform: translateX(-50%);
            }
            75% {
                transform: translateX(-25%);
            }
            100% {
                transform: translateX(1);
            }
        }

        .container {
            background: rgba(255, 255, 255, 0.15); /* Semi-transparent white background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 900px;
            width: 90%;
            margin: 120px 20px 20px; /* Added top margin to create space from navbar */
            text-align: center;
            backdrop-filter: blur(10px); /* Blur effect for glass effect */
            -webkit-backdrop-filter: blur(10px); /* For Safari */
            position: relative;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #555;
            line-height: 1.6;
            margin-bottom: 20px;
            text-align: left; /* Align text left */
        }

        .profile-container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px 0;
        }

        .profile {
            text-align: center;
            margin: 20px;
            width: 250px; /* Adjust width as needed */
        }

        .profile img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ccc;
        }

        .profile h2 {
            font-size: 1.2em;
            margin: 10px 0 5px;
            color: #333;
        }

        .profile p {
            color: #777;
            font-size: 0.9em;
            text-align: left; /* Align text left */
        }

        .video-history {
            margin-top: 40px;
            text-align: left; /* Align text left */
        }

        .video-history h2 {
            color: #333;
            margin-bottom: 15px;
        }

        .video-history table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .video-history th, .video-history td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
            color: #555;
        }

        .video-history th {
            background-color: #f2f2f2;
        }

        .video-history tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .video-history tr:hover {
            background-color: #f1f1f1;
        }

        .social-links a {
            margin: 0 10px;
            color: #555;
            text-decoration: none;
            transition: color 0.3s;
        }

        .social-links a:hover {
            color: #333;
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 15px 50px;
            background: #E01A4F;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .nav .logo {
            font-size: 22px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
        }

        .nav .nav-links {
            display: flex;
            list-style: none;
            column-gap: 20px;
        }

        .nav .nav-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.2s linear;
        }

        .nav .search-icon {
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }

        .search-box {
            position: absolute;
            top: calc(100% + 10px);
            right: 50%;
            transform: translateX(50%);
            width: 300px;
            max-width: calc(100% - 20px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.2s linear;
            z-index: 10;
        }

        .search-box .search-icon {
            position: absolute;
            top: 50%;
            left: 20px;
            transform: translateY(-50%);
            color: #ccc;
        }

        .search-box input {
            width: 100%;
            padding: 15px 20px 15px 45px;
            border: 2px solid rgba(0, 0, 0, 0.05);
            border-radius: 50px;
            outline: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .search-box.active {
            opacity: 1;
            pointer-events: auto;
        }

        @media screen and (max-width: 768px) {
            .container {
                margin: 80px 0 0;
            }

            .nav {
                padding: 10px 20px;
            }

            .nav .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                height: 100%;
                width: 100%;
                max-width: 400px;
                background: #fff;
                flex-direction: column;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                padding: 60px 20px;
                row-gap: 30px;
                transition: all 0.3s ease;
            }

            .nav .nav-links a {
                color: #4a4a4a;
            }

            .nav .nav-links.active {
                left: 0;
            }

            .nav .navOpenBtn,
            .nav .navCloseBtn {
                display: block;
            }

            .nav .navOpenBtn {
                font-size: 22px;
                color: #fff;
                cursor: pointer;
            }

            .nav .navCloseBtn {
                position: absolute;
                top: 20px;
                right: 20px;
                color: #4a4a4a;
                font-size: 22px;
                cursor: pointer;
            }

            .search-box {
                width: 95%;
                max-width: 95%;
                right: 20px;
                transform: translateX(0);
            }

            .profile {
                width: 100%;
            }
        }

        .update-button {
            background-color: #007BFF; /* Blue background */
            color: #fff; /* White text */
            border: none; /* Remove default border */
            padding: 10px 20px; /* Padding for size */
            border-radius: 30px; /* More rounded corners */
            font-size: 16px; /* Font size */
            font-weight: 600; /* Slightly bolder text */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth transitions */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); /* More prominent shadow */
        }

        .update-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: translateY(-2px); /* Lift effect on hover */
        }

        .update-button:active {
            background-color: #004494; /* Even darker blue on click */
            transform: translateY(0); /* Return to normal position on click */
        }
    </style>

</head>
<body>
<nav class="nav">
    <i class="uil uil-bars navOpenBtn"></i>
    <a href="#" class="logo">Puihaha Video Production</a>
    <ul class="nav-links">
        <li><a href="homepage.php">Home</a></li>
        <li><a href="add.php">Add A Movie</a></li>
            <li><a href="rent.php">Rent A Movie</a></li>
            <li><a href="return.php">Return a Movie</a></li>
            <li><a href="viewprof.php">Profile</a></li>
            <li><a href="aboutpage.php">About Us</a></li>
            <li><a href="logout.php" onclick="confirmLogout(event);">Logout</a></li>
    </ul>
    <i class="uil uil-search search-icon" id="searchIcon"></i>
    <div class="search-box">
        <i class="uil uil-search search-icon"></i>
        <input type="text" placeholder="Search here..." />
    </div>
</nav>

<div class="container">
    <h1>View Profile</h1>
    <div class="profile-container">
    <div class="profile-container">
        <div class="profile">
            <img src="https://icons.veryicon.com/png/o/miscellaneous/standard/avatar-15.png" alt="Profile Picture">
            <h2><?php echo htmlspecialchars($username); ?></h2>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
            <!-- Add more user details as needed -->
            <button class="update-button" onclick="window.location.href='updateprofile.php'">Update Profile</button>
        </div>
    </div>
    </div>

    <div class="video-history">
        <h2>Video Rental History</h2>
        <table>
            <thead>
                <tr>
                    <th>Movie Title</th>
                    <th>Rental Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rentals as $rental) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($rental['movie_id']); ?></td>
                    <td><?php echo htmlspecialchars($rental['rental_date']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- JavaScript for displaying update success message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php
        if (isset($_SESSION['update_success'])) {
            echo "alert('Profile updated successfully!');";
            unset($_SESSION['update_success']);
        }
        ?>
    });
</script>

</body>
</html>
